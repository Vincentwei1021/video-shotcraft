---
name: icon-performance-moves
一句话: 图标表演——attention-bounce 求关注弹跳（图标连跳递增+落地压扁+镜头被吸引）
适用: 半屏级 icon 特写段落；新功能引出
时长: 156f（5.2s）
能量: 蓄势引入
标签: interaction
---

## 意图
库内图标动画品类首批入库：icon 是镜头怼着拍的表演者，不是 UI 角落的
微交互。attention-bounce 是 macOS Dock 语汇——Dock 里的 video-shotcraft
app 图标原地连跳 4 次一次比一次高（0.35→1.2 倍 icon 高），每次落地压扁
（末跳宽 1.2x 高 0.8x）+涟漪溅点，邻居图标逐渐失焦、跳最高那下镜头向它
轻推 8%（被吸引），落定后弹开「New in Shotcraft」功能面板——把"用户注意力"
剪进叙事。

## 做法
| 式 | 做法 | 适用 |
|----|------|------|
| A attention-bounce | 抛体弹跳（时长 ∝ √高度）递增 + 空中速度拉伸 + 落地 2f 挤压 + 涟漪溅点，邻居 rack focus 失焦，峰值跳镜头 scale 1.08 推近，落定触发角标 + 面板弹簧展开 | 新功能引出："看我"→镜头看它→它开面板 |

## 参数表
| 参数 | 典型值 | 调节手感 |
|------|--------|----------|
| icon 尺寸 | 360–400px 高（半屏特写；demo 图标 360） | 角落小图标做表演没人看见——表演者必须占 C 位 |
| 递增弹跳 | 4 跳 0.35→0.6→0.85→1.2 倍 icon 高，空中 14/18/22/26f（∝ √高度） | 等高连跳读作 loading；递增才是"越喊越大声"；时长不随高度变读作失重 |
| 落地挤压 | 接触 2f，压扁量 0.1→0.2 递增（末跳宽 1.2x 高 0.8x），末跳阻尼余弦回稳 | squash 缺席=没有重量 |
| 镜头推近 | 末跳 72–90f smooth 推 8%；邻居 30–96f 失焦到 7px、降饱和 30% | 镜头动作把"被吸引"的观众视角演出来 |

## 已知坑
- demo 在灰阶/占位素材上调校通过——参数是调校起点非实战定稿，
  首次实战须以真实素材回验
- 同批 bell-swing-alert（铃铛甩摆）淘汰无附言——挂点摆动型 icon
  表演相性存疑，做新 icon 表演优先弹跳/爆发型
- 首版曾出画框（末跳最高点顶出），弹跳高度与画面上留白先算像素
  （demo：地面 960、图标 360、末跳顶点 168px，推近 8% 后约 119px）
- 声音：每次落地一声"duk"音调递升，面板弹出一声轻"叮"

## 参考实现
[完整工程 demos/effects/icon-performance-moves/](https://github.com/Vincentwei1021/video-shotcraft/tree/main/demos/effects/icon-performance-moves)
（AttentionBounce.tsx）
