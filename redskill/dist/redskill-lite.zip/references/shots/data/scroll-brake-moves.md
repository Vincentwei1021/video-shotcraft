---
name: scroll-brake-moves
一句话: 长卷急刹两式——changelog-scroll-brake 基本款（高速长卷指数减速精准停位+目标抬升）与 brake-reticle-lock 组合款（急刹帧同帧准星咬合）
适用: changelog/发布史/长列表段落："一直在发货，今天这条最大"；要给停点更强打击感用 B
时长: A 4–5s / B 5s
能量: 高开中收（速度对比型）
标签: rhythm
---

## 意图
Linear changelog 视频语法：一整年的更新日志作为长卷高速掠过
（糊成色带），指数减速精准急刹停在本次发布那条上，该条抬升离面
高亮、其余退暗——密度感讲"一直在发货"，急停讲"今天这条最大"。
B 是组合变异：急刹帧**同帧**四个 L 角标从画外飞入咬合锁定停点
条目——急刹的"哐"与咬合的"咔"叠在同一帧共振（组合命门：
角标起跳帧=列表首停帧，错开退化成两招并置）。

## 两式选型
| 式 | 做法 | 适用 |
|----|------|------|
| A changelog-scroll-brake | translateY 扫 ~2400px（cubic-bezier(.45,0,.06,1)：~5f 拉满速再长尾指数式减速，共 50f），纵向方向性 blur 由帧间位移差分驱动（×0.32 封顶 30px，停稳自动清零）；停点行 scale 1.03 抬升+阴影+2px 强调色描边，其余 opacity 退 0.38 | changelog 段落基本款 |
| B brake-reticle-lock | 滚动三段：sin-in 加速→cubic-out 猛减速冲过头 +30px→回弹落定；纵向方向性 blur=v×0.15 封顶 32px；角标从 ±620/±320 画外 Easing.back(2.4) 飞入咬合，高亮 6f 内完成、标签 back(2.6) 弹出 | 停点需要更强打击感的高光段 |

## 参数表
| 参数 | 典型值 | 调节手感 |
|------|--------|----------|
| 减速曲线 | A 快起步 + 长尾减速（bezier .45,0,.06,1）；B 加"冲过头 30px 回弹" | 匀速滚读作跑马灯；B 的过头回弹是"哐"的来源 |
| blur 驱动 | 帧间位移差分 `|p(f)-p(f-1)|`×系数 | 手排模糊关键帧必然对不上速度；差分法帧确定（模式已沉为 [完整工程 assets/lib/helpers/motion.ts](https://github.com/Vincentwei1021/video-shotcraft/blob/main/assets/lib/helpers/motion.ts) velocityAt） |
| 行高节奏 | 72/94/116 三档错落 | 等高行高速掠过时色带无节奏 |
| 停位 | 目标行停画面纵向正中 | 停偏读作事故 |
| B 共振帧 | 角标挂载起跳帧 = 列表首次停住帧（严格同帧） | 组合命门，错 2f 以上就散 |

## 已知坑
- demo 在灰阶/占位素材上调校通过——参数是调校起点非实战定稿，
  首次实战须以真实素材回验
- 与 timeline-travel 分工：本卡纵向列表急刹停"最新"，
  那卡横向时间轴旅行看"历史"——同片双用时先后错开且各 ≤1 次
- 高速段条目内容不用真实可读文本——反正糊成色带，占位灰块即可；
  停点条目必须出版级真内容（Q10）
- 停点后其余行退暗 0.38 是构图动作：别退到 0（上下文消失）
- 声音：高速段低频 riser 铺垫，急刹一声 impact；B 咬合帧
  再叠一声"咔"（与 impact 同帧不同声部）

## 参考实现
[完整工程 demos/data/scroll-brake-moves/](https://github.com/Vincentwei1021/video-shotcraft/tree/main/demos/data/scroll-brake-moves)
（BrakeReticleLock.tsx / ChangelogScrollBrake.tsx）
